UK AQ Integrity diagnostic bundle
=================================

Environment: LIVE
Created UTC: 2026-10-11T18:47:41.310735+00:00
Selected tmp run roots: /Users/mikehinford/uk-aq-history-integrity/state/LIVE/tmp/run-2026-10-11T184541Z

This bundle contains diagnostic files only. It deliberately excludes Parquet data, SQLite databases, env files, and files with obvious credential or token names.
