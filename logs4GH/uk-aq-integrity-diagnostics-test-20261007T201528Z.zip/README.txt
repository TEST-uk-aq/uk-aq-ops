UK AQ Integrity diagnostic bundle
=================================

Environment: TEST
Created UTC: 2026-10-07T20:15:35.804862+00:00
Selected tmp run roots: /Users/mikehinford/uk-aq-history-integrity/state/TEST/tmp/run-2026-10-07T200426Z

This bundle contains diagnostic files only. It deliberately excludes Parquet data, SQLite databases, env files, and files with obvious credential or token names.
